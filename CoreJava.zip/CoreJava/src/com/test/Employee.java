package com.test;

public class Employee {
	private Integer empi_id;
	private String emp_name;
	private Double salary;
	
	public Integer getEmpi_id() {
		return empi_id;
	}
	public void setEmpi_id(Integer empi_id) {
		this.empi_id = empi_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	

}
